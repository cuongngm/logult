# logger_rewrite
Easy way to log everything
### Install
```bash
pip install logger_rewrite
```

### Use
```bash
from logger_rewrite import setup_log
logger = setup_log(save_dir='saved')
logger.info('Hello world')
```
